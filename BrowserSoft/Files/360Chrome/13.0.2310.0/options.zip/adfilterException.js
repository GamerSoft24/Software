/**
 * define adfilterExceptionOptions 
 * 
 ***/
cr.define('options', function () {
    var OptionsPage = options.OptionsPage;

    function ADFilterExceptionOptions() {
        OptionsPage.call(this, 'adfilterException', templateData.adFilterPageTabTitle, 'adfilterExceptionPage');
    }

    cr.addSingletonGetter(ADFilterExceptionOptions);

    ADFilterExceptionOptions.prototype = {
        __proto__: options.OptionsPage.prototype,

        initializePage: function () {
            OptionsPage.prototype.initializePage.call(this);
            var adExceptionList = $("adfilterExceptionList");
            options.contentSettings.ExceptionsList.decorate(adExceptionList);
        } //initializePage
    };
    return {
        ADFilterExceptionOptions: ADFilterExceptionOptions
    };
});