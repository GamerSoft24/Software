﻿var $ = function(id) {
    return document.getElementById(id);
  },
  checkstring = function(str, arr) {
    return (str != '' && arr.toString().indexOf(str) > -1);
  },
  make_sug = function(kn, jy) {
    return kn;
    // return 'Possible Causes:' + kn + '<br/>Suggested Action:' + jy;
  },
  setTitle = function() {
    document.title = $("tips-title").innerHTML;
  },
  showErrorSearchForm = function() {
    iframeLoadTimeout = true;
    iframe.style.display = 'none';
    resStatus.style.display = 'none';
    fm.style.display = 'inline-block';
    fm.focus();
  },
  sug_text,
  shownetfixbt = function() {
    $("suggestion").innerHTML = make_sug(sug_text || "Abnormal URL connection, firewall or anti-virus software blocking, security issues", "Abnormal website connection, firewall or anti-virus software blocking, security issues, check the network connection status, or use 360 to disconnect");
    $("btn-jijiuxiang").style.display = "inline-block";
    $("btn-jijiuxiang").onclick = function() {
      // Adjust twice so that the first aid kit window is at the front
      chrome.send('startnetfix');
      chrome.send('startnetfix');
    }
  },
  get_domain = function(str) {
    var urlReg = /[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/;
    var url = urlReg.exec(str);
    if (url)
      return url[0];
    else
      return "";
  },
  is_ip = function(str) {
    var re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/;
    if (re.test(str)) {
      if (RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256) return true;
    }
    return false;
  },
  get_download_site_url = function() {
    var url = '';
    if (sysinfo_ == 'winxp32') {
      return url + '77';
    } else if (sysinfo_ == 'winvista32') {
      return url + '105043';
    } else if (sysinfo_ == 'winvista64') {
      return url + '105045';
    } else if (sysinfo_ == 'win732') {
      return url + '102630048';
    } else if (sysinfo_ == 'win764') {
      return url + '102630050';
    } else {
      return '';
    }
  },
  create_ie_btns = function() {
    var download_site = document.createElement('button');
    download_site.textContent = 'Reinstall the stable version of IE';
    download_site.style.display = 'inline-block';
    download_site.className = 'greenbtn';
    download_site.id = 'download_site';
    download_site.onclick = function() {
      chrome.send('navigateToUrl', [get_download_site_url(), '', 0, false, false, false, false]);
    };
    var expert_help = document.createElement('button');
    expert_help.textContent = 'Computer Expert Help';
    expert_help.style.display = 'inline-block';
    expert_help.className = 'graybtn';
    expert_help.id = 'expert_help';
    expert_help.onclick = function() {
      chrome.send('navigateToUrl', ['', '', 0, false, false, false, false]);
    };
    var btns_div = document.querySelector('.error-btns');
    btns_div.appendChild(download_site);
    btns_div.appendChild(expert_help);
  },
  fm = $("error-search").querySelector('form'),
  iframe = $("error-search").querySelector('iframe'),
  resStatus = $('resStatus'),
  iframeLoaded = false,
  iframeLoadTimeout = false,
  iframeTimer,
  focus_num = 0,
  showerrorinfo = function(errorcode, lasterrorurl) {
    //var errorcode = $('errorcode').innerHTML, lasterrorurl = $("lasterrorurl").innerHTML;
    if (lasterrorurl == '') {
      return;
    }

    iframeLoaded = false;
    iframeLoadTimeout = false;
    clearTimeout(iframeTimer);
    //Initialization
    var btnObj = {
        "btn-refesh": "Refresh page",
        "btn-goback": "Go back to the last page",
        "btn-gohome": "Go to the homepage",
        "btn-jijiuxiang": "360 Disconnected First Aid Kit",
        "btn-close": "Shut Down"
      },
      searchFormObj = {
        "error_search_tip": "You can also search for relevant information on the web:",
        "search-q": "Please enter key words",
        "error_search_btn": "Search"
      };
    for (var i in btnObj) {
      $(i).innerHTML = btnObj[i];
    }
    for (var i in searchFormObj) {
      if (i == 'search-q') {
        $(i).setAttribute('placeholder', searchFormObj[i]);
      } else if (i == 'error_search_btn') {
        $(i).value = searchFormObj[i];
      } else {
        $(i).innerHTML = searchFormObj[i];
      }
    }
    $("btn-refesh").style.display = "none";
    $("btn-goback").style.display = "none";
    $("btn-gohome").style.display = "none";
    $("btn-jijiuxiang").style.display = "none";
    $("btn-close").style.display = "none";

    if ($('download_site')) $('download_site').remove();
    if ($('expert_help')) $('expert_help').remove();

    //Error code combination
    var
      e_dns = [104, 105],
      e_link = [403, 405, 406, 500],
      e_net = [118, 106, 324, 138, 109, 130, 331, 346, 349, 350, 107, 128, 117, 129, 132, 143, 20, 150];

    if (checkstring(errorcode, e_dns) == true) {
      sug_text = "Please check the spelling of the domain name, or check the network";
      //DnsProblem
      $("btn-refesh").style.display = "inline-block";
      $("tips-title").innerHTML = "Domain name resolution error";
      setTitle();
      $("tips-type").innerHTML = "(Failed to resolve DNS analysis)";
      $("suggestion").innerHTML = make_sug(sug_text);
      //Check if there is a first aid kit
      chrome.send('installednetfix');
    } else if (checkstring(errorcode, e_net) == true || checkstring(errorcode, e_link) == true) {
      var is_e_link = checkstring(errorcode, e_link) == true;
      sug_text = is_e_link ? "(error code" + errorcode + ")" : "Please check the spelling of the domain name, or check the network";
      //Network problem, search is not displayed
      $("btn-refesh").style.display = "inline-block";
      $("tips-title").innerHTML = is_e_link ? "Webpage is not accessible" : "Network connection error";
      setTitle();
      $("tips-type").innerHTML = "(Network Error)";
      $("suggestion").innerHTML = make_sug(sug_text);
      $("error-search").style.display = "none";
      //Check if there is a first aid kit
      chrome.send('installednetfix');
    } else if (errorcode == 404) {
      //404
      $(history.length > 1 ? "btn-goback" : "btn-close").style.display = "inline-block";
      $("btn-gohome").style.display = "inline-block";
      $("tips-title").innerHTML = "The page does not exist or has been deleted";
      setTitle();
      $("tips-type").innerHTML = "(error 404)";
      $("suggestion").innerHTML = make_sug("(error code" + errorcode + ")", "Check if the URL is correct");
    } else if (errorcode == 0x80040154 || errorcode == 0x80040155) {
      $("tips-title").innerHTML = "IE Browser is abnormal";
      setTitle();
      $("tips-type").innerHTML = "(IE kernel call error)";
      var kn = "Your Internet Explorer program may be corrupted";
      $("suggestion").innerHTML = 'Possible Causes:' + kn + '<br/>The following actions are recommended:';
      $("error-search").style.display = "none";
      create_ie_btns();
    } else {
      //Other problems
      $("btn-refesh").style.display = "inline-block";
      $("tips-title").innerHTML = "There was an error in the page you visited!";
      setTitle();
      $("tips-type").innerHTML = "(error in connecting)";
      $("suggestion").innerHTML = make_sug("Abnormal network connection, website server unresponsive", "Refresh and retry");
    }
    var lasterrorurldomain = get_domain(lasterrorurl),
      type_arr = lasterrorurl.split('://'),
      type_text = type_arr[0] != '' && lasterrorurl.indexOf('://') > 0 ? type_arr[0] + '://' : '',
      min_domain = lasterrorurldomain,
      min_domain_arr = min_domain.split('.'),
      domain_len = min_domain_arr.length;
    if (is_ip(min_domain)) {} else if (domain_len == 3 && min_domain_arr[0] != 'www') {
      min_domain = 'www.' + min_domain_arr[1] + '.' + min_domain_arr[2];
    } else if (domain_len > 3) {
      min_domain = 'www.' + min_domain_arr[domain_len - 2] + '.' + min_domain_arr[domain_len - 1];
    }

    if ($("error-search").style.display != 'none') {
      fm.querySelector('input[name="src"]').value = '360chrome_errorpage_' + errorcode;
      iframe.src = '';
      iframe.onload = function() {
        if (iframeLoadTimeout) return;
        iframeLoaded = true;
        iframe.style.display = 'inline-block';
        fm.style.display = 'none';
        var hsr = 'HIDE_SEARCH_RESULT',
          resStatusFunc = function(hide) {
            if (hide) {
              iframe.style.height = '40px';
              resStatus.innerText = 'Show search results';
              localStorage[hsr] = 1;
            } else {
              iframe.style.height = '610px';
              resStatus.innerText = 'Hide search results';
              localStorage.removeItem(hsr);
            }
          };
        resStatusFunc(localStorage[hsr]);
        resStatus.style.display = 'inline-block';
        resStatus.onclick = function() {
          resStatusFunc(!localStorage[hsr]);
        };
        if (window.networkOK) {
          $("error-search").style.display = 'block';
        }
        $('t').style.display = "block";
      }
      iframeTimer = setTimeout(function() {
        if (!iframeLoaded) {
          showErrorSearchForm();
          // $("error-search").style.display = 'block';
          $('t').style.display = "block";
        }
      }, 3000);
    } else {
      $('t').style.display = "block";
    }
    //$("btn-refesh").href = lasterrorurl;
    $("btn-gohome").href = type_text + min_domain;
    $("search-q").value = ''; //lasterrorurl.replace(type_text, '');

    $("search-q").onfocus = function() {
      if (focus_num == 0) {
        focus++;
        var _this = this;
        setTimeout(function() {
          _this.select();
        }, 20);
      }
    };
    $("search-q").onblur = function() {
      focus_num = 0;
    };
    $("btn-goback").onclick = function() {
      history.back();
      return false;
    };
    $("btn-close").onclick = function() {
      window.close();
      return false;
    };
    $("btn-refesh").onclick = function() {
      window.location = lasterrorurl;
      return false;
    };
  },
  responsesysinfo = function(sysinfo) {
    window.sysinfo_ = sysinfo;
    chrome.send('geterrorinfo');
  };
chrome.send('getsysinfo');